ESP-IDF template app
====================
 esp32-cam 
 пробная задача
успешно освоен пример.

с видеокамеры esp32-cam
  на web-server => wifi => на ПК 