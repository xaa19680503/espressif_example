ESP-IDF template app
====================
запись на cd  с видеокамеры