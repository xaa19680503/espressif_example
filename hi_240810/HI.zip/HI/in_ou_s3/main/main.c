#include "hal/gpio_types.h"
#include <string.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>
#include <driver/gpio.h>

#include "freertos/FreeRTOS.h"
#include "soc/gpio_num.h"
//include "freertos/task.h"
//#include <freertos/queue.h>

#define key_1  GPIO_NUM_12
#define key_2  GPIO_NUM_13
#define key_3  GPIO_NUM_14

#define key_4  GPIO_NUM_11
#define key_5  GPIO_NUM_10


#define led_1  GPIO_NUM_38
#define led_2  GPIO_NUM_48

#define led_3   GPIO_NUM_35
#define led_4   GPIO_NUM_36
#define led_5   GPIO_NUM_37

#define led_6   GPIO_NUM_44
#define led_7   GPIO_NUM_40
#define led_8   GPIO_NUM_41
#define led_9   GPIO_NUM_43


//QueueHandle_t gpio_evt_queue = NULL;
static int k1_on_off=0,  k2_on_off=0,  k_on_off=0;
static int k3_on_off=0,  k4_on_off=0,  k5_on_off=0;

static void  IRAM_ATTR  int_key_1(void* arg)
{ gpio_intr_disable(key_1); 
  k_on_off=1;   k1_on_off=1;
   {gpio_set_level(led_1,  1);}
   {gpio_set_level(led_2 ,  0);}
   {gpio_set_level(led_3 ,  1);}
   {gpio_set_level(led_4 ,  0);}
   {gpio_set_level(led_5 ,  0);}
   {gpio_set_level(led_6,  0);} 
   {gpio_set_level(led_7 ,  0);}
   {gpio_set_level(led_8 ,  0);}
   {gpio_set_level(led_9,  0);} 
   
   
//uint32_t gpio_n = (uint32_t) arg;
  //   xQueueSendFromISR(gpio_evt_queue, &gpio_n, NULL);
//gpio_intr_enable(key_1);     
}////////   //////////  /////////

static void  IRAM_ATTR int_key_2(void* arg)
{gpio_intr_disable(key_2);    
  k_on_off=2;   k2_on_off=2;
   {gpio_set_level(led_1,  0);}
   {gpio_set_level(led_2 ,  1);}
   {gpio_set_level(led_3 ,  0);}
   {gpio_set_level(led_4 ,  1);}
   {gpio_set_level(led_5 ,  0);}
   {gpio_set_level(led_6,  1);}     
   {gpio_set_level(led_7 ,  0);}
   {gpio_set_level(led_8 ,  0);}
   {gpio_set_level(led_9,  0);} 
   
  //  uint32_t gpio_n = (uint32_t) arg;
  //   xQueueSendFromISR(gpio_evt_queue, &gpio_n, NULL);
//gpio_intr_enable(key_2);  	 
}////////   //////////  /////////

static void  IRAM_ATTR int_key_3(void* arg)
{ gpio_intr_disable(key_3);
  k_on_off=3;   k3_on_off=3;
   {gpio_set_level(led_1,  1);}
   {gpio_set_level(led_2 ,  1);}
   {gpio_set_level(led_3 ,  0);}
   {gpio_set_level(led_4 ,  0);}
   {gpio_set_level(led_5 ,  1);}
   {gpio_set_level(led_6,  0);}    
   {gpio_set_level(led_6,  !0);} 
   {gpio_set_level(led_7 ,  1);}
   {gpio_set_level(led_8 ,  0);}
   {gpio_set_level(led_9,  0);} 

 //   uint32_t gpio_n = (uint32_t) arg;
  //   xQueueSendFromISR(gpio_evt_queue, &gpio_n, NULL);	 
//gpio_intr_enable(key_3);	
}////////   //////////  /////////

static void  IRAM_ATTR int_key_4(void* arg)
{ gpio_intr_disable(key_4);
  k_on_off=4;   k4_on_off=4;
   {gpio_set_level(led_1,  0);}
   {gpio_set_level(led_2 ,  0);}
   {gpio_set_level(led_3 ,  1);}
   {gpio_set_level(led_4 ,  1);}
   {gpio_set_level(led_5 ,  0);}
   {gpio_set_level(led_6,  0);}     
   {gpio_set_level(led_6,  0);} 
   {gpio_set_level(led_7 ,  0);}
   {gpio_set_level(led_8 ,  1);}
   {gpio_set_level(led_9,  0);} 

 //   uint32_t gpio_n = (uint32_t) arg;
  //   xQueueSendFromISR(gpio_evt_queue, &gpio_n, NULL);	 
//gpio_intr_enable(key_4);	
}////////   //////////  /////////

static void  IRAM_ATTR int_key_5(void* arg)
{ gpio_intr_disable(key_5);
  k_on_off=5;   k5_on_off=5;
   {gpio_set_level(led_1,  1);}
   {gpio_set_level(led_2 ,  1);}
   {gpio_set_level(led_3 ,  0);}
   {gpio_set_level(led_4 ,  1);}
   {gpio_set_level(led_5 ,  1);}
   {gpio_set_level(led_6,  0);}     
   {gpio_set_level(led_6,  0);} 
   {gpio_set_level(led_7 ,  0);}
   {gpio_set_level(led_8 ,  0);}
   {gpio_set_level(led_9,  1);} 

 //   uint32_t gpio_n = (uint32_t) arg;
  //   xQueueSendFromISR(gpio_evt_queue, &gpio_n, NULL);	 
//gpio_intr_enable(key_5);	
}////////   //////////  /////////



void cfg_inp(void)///////////////////////////////////////////
{ gpio_reset_pin( key_1); 
  gpio_set_direction( key_1,  GPIO_MODE_INPUT); 
  gpio_set_pull_mode( key_1,  GPIO_PULLUP_ONLY);
    
  gpio_reset_pin(key_2);  
  gpio_set_direction( key_2,  GPIO_MODE_INPUT );  
  gpio_set_pull_mode( key_2,  GPIO_PULLUP_ONLY);

  gpio_reset_pin(key_3);  
  gpio_set_direction( key_3,  GPIO_MODE_INPUT );  
  gpio_set_pull_mode( key_3,  GPIO_PULLUP_ONLY); 	

  gpio_reset_pin(key_4);  
  gpio_set_direction( key_4,  GPIO_MODE_INPUT );  
  gpio_set_pull_mode( key_4,  GPIO_PULLUP_ONLY);

  gpio_reset_pin(key_5);  
  gpio_set_direction( key_5,  GPIO_MODE_INPUT );  
  gpio_set_pull_mode( key_5,  GPIO_PULLUP_ONLY);    
}///////////////////////////////

void cfg_out(void)
{ gpio_reset_pin(led_1);  
  gpio_set_direction( led_1,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_1,  GPIO_FLOATING);
  
  gpio_reset_pin(led_2);  
  gpio_set_direction( led_2,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_2,  GPIO_FLOATING);

  gpio_reset_pin(led_3);  
  gpio_set_direction( led_3,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_3,  GPIO_FLOATING);

  gpio_reset_pin(led_4);  
  gpio_set_direction( led_4,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_4,  GPIO_FLOATING);
      
  gpio_reset_pin(led_5);  
  gpio_set_direction( led_5,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_5,  GPIO_FLOATING);      

  gpio_reset_pin(led_6);  
  gpio_set_direction( led_6,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_6,  GPIO_FLOATING);
  
  gpio_reset_pin(led_7);  
  gpio_set_direction( led_7,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_7,  GPIO_FLOATING);      

  gpio_reset_pin(led_8);  
  gpio_set_direction( led_8,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_8,  GPIO_FLOATING);

  gpio_reset_pin(led_9);  
  gpio_set_direction( led_9,  GPIO_MODE_OUTPUT  );  
  gpio_set_pull_mode( led_9,  GPIO_FLOATING);      
 	
}/////////////////////////////////------------------------------------------------
void cfg_int_inp(void)
{  gpio_set_intr_type(key_1, GPIO_INTR_ANYEDGE  );  
   gpio_set_intr_type(key_2, GPIO_INTR_ANYEDGE  );  
   gpio_set_intr_type(key_3, GPIO_INTR_ANYEDGE  );  
   gpio_set_intr_type(key_4, GPIO_INTR_ANYEDGE  );
   gpio_set_intr_type(key_5, GPIO_INTR_ANYEDGE  );
      
 esp_err_t err = gpio_install_isr_service(0);
 if (err == ESP_ERR_INVALID_STATE) 
     { printf( "GPIO isr service already installed"); };   
     gpio_isr_handler_add(key_1, int_key_1, (void *)key_1); 
     gpio_isr_handler_add(key_2, int_key_2, (void *)key_2);
     gpio_isr_handler_add(key_3, int_key_3, (void *)key_3);                 
     gpio_isr_handler_add(key_4, int_key_4, (void *)key_4);
     gpio_isr_handler_add(key_5, int_key_5, (void *)key_5);          
     gpio_intr_enable(key_1);  
     gpio_intr_enable(key_2);   
     gpio_intr_enable(key_3);
     gpio_intr_enable(key_4);
     gpio_intr_enable(key_5);          
 	
}///////////////////////////////////////
//------------------------------------------------
void app_main(void) /////////////////////////   
{gpio_reset_pin(GPIO_NUM_20);
 gpio_reset_pin(GPIO_NUM_21);
 gpio_reset_pin(GPIO_NUM_19); 
	
	   cfg_inp(); cfg_out(); uint8_t t=0; uint8_t clk=0;  
  
// gpio_evt_queue = xQueueCreate(10, sizeof(uint32_t));
//    xTaskCreate(task1, "task1", 2048, NULL, 10, NULL);
     cfg_int_inp();
 
while (1) {    printf("Hello from app_main!\n %d , clk = %d k1= %d k2=%d k3=%d int=%d \n", t, clk, 
                          gpio_get_level(key_1),
                          gpio_get_level(key_2),
                          gpio_get_level(key_3),
                          k_on_off
                          );
//    clk++; if (clk>10) clk=0;			   //--задаёт условие мигания  двух светодиодов--
//if (t==0  )  {t=1; } else {t=0;}  //--задаёт условие мигания  светодиода--
// if (k1_on_off==0) { //если не была нажата кнопа           
//               gpio_set_level(led_2,  t);         
//   if (clk<5){ gpio_set_level(led_15,  !t);} else {gpio_set_level(led_15,  !0);}
//   if (clk>5){ gpio_set_level(led_4,  !t); } else {gpio_set_level(led_4 ,  !0);}
//   }               
      sleep(1); //задержка       
if (k_on_off>0)  //если была нажата кнопа
     {
	  if (k1_on_off==1)    gpio_intr_enable(key_1);
     if (k2_on_off==2)    gpio_intr_enable(key_2);
   if (k3_on_off==3)    gpio_intr_enable(key_3);
 if (k4_on_off==4)    gpio_intr_enable(key_4);
      if (k5_on_off==5)    gpio_intr_enable(key_5);                       
          k_on_off=0; 
     }  

  }
}