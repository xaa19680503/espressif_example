# Example Project

This is both ESP-IDF and PlatformIO project.

## Build and Flash as ESP-IDF Project

```sh
idf.py build flash monitor
```

## Build and Flash as PlatformIO Project

```sh
platformio run -t upload
```
